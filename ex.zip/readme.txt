nota




	block_crawler.php - sera o index da pagina 
se nao conectar use as seggintes infos no bitmillion.conf 
rpcuser=rpc_user
rpcpassword=8cde5e64e7297b1cb4c495d1a
rpcallowip=127.0.0.1
rpcport=31836
listen=1
server=1